<?php
include (dirname(__FILE__).DS.'index.php');