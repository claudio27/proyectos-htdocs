<?php
/** 
 * Configuración básica de WordPress.
 *
 * Este archivo contiene las siguientes configuraciones: ajustes de MySQL, prefijo de tablas,
 * claves secretas, idioma de WordPress y ABSPATH. Para obtener más información,
 * visita la página del Codex{@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} . Los ajustes de MySQL te los proporcionará tu proveedor de alojamiento web.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** Ajustes de MySQL. Solicita estos datos a tu proveedor de alojamiento web. ** //
/** El nombre de tu base de datos de WordPress */
define('DB_NAME', 'a9535807_tres');

/** Tu nombre de usuario de MySQL */
define('DB_USER', 'a9535807_root');

/** Tu contraseña de MySQL */
define('DB_PASSWORD', 'tres3213');

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', 'mysql14.000webhost.com');

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8');

/** Cotejamiento de la base de datos. No lo modifiques si tienes dudas. */
define('DB_COLLATE', '');

/**#@+
 * Claves únicas de autentificación.
 *
 * Define cada clave secreta con una frase aleatoria distinta.
 * Puedes generarlas usando el {@link https://api.wordpress.org/secret-key/1.1/salt/ servicio de claves secretas de WordPress}
 * Puedes cambiar las claves en cualquier momento para invalidar todas las cookies existentes. Esto forzará a todos los usuarios a volver a hacer login.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '|=fZjSZ?-G;XTUu#4P+Z<Tf:<+@yz[@BsC/:1;pn;&+IF| `K5Z-l7)%k0Wuu%B%'); // Cambia esto por tu frase aleatoria.
define('SECURE_AUTH_KEY', '%5~|MNg9i:NINA9IzDt&y(MQFs4Aj700(s18Ol> |91p<%A-GLro:_gMZ$l@@Q:='); // Cambia esto por tu frase aleatoria.
define('LOGGED_IN_KEY', 'J=Icg6>[,~~q=`a?>Zo.k/5{=Zn;7mAoHgC)#YO+!Nb`E>-{`|G=@=jh-wZr== +'); // Cambia esto por tu frase aleatoria.
define('NONCE_KEY', 'BSpg>EXHs!`R%t.2[~GmNV/H)49j$]B,$tTF/)/89HRe3Tn:gmZQtdm>lAS[&YU{'); // Cambia esto por tu frase aleatoria.
define('AUTH_SALT', 'r$Uis<B$QyON!?#h,l7m>3_i>qd0D^0)~RCj+QR_@24Ybj-pCo-![eO$wQ@5z~/N'); // Cambia esto por tu frase aleatoria.
define('SECURE_AUTH_SALT', 'Y4xOsS(KpH~!]9.()?.GA:R*7~9#IeW)kXl|VEs`,FoGIXnV;z.&|ipAk@QLe~`8'); // Cambia esto por tu frase aleatoria.
define('LOGGED_IN_SALT', 'y%u8G:ATkxfUd6 vHfvh:~67/29|Pbm`DBGB>kX_tO*I-V=(w)X)Aj(G;D.UKX.i'); // Cambia esto por tu frase aleatoria.
define('NONCE_SALT', ':)%}-YV8lH.K,D`MQ_3^Z,xcj&j!0@sJbc(X[Ht.e|)|N^7wBb[K>TC<4nH+0ct!'); // Cambia esto por tu frase aleatoria.

/**#@-*/

/**
 * Prefijo de la base de datos de WordPress.
 *
 * Cambia el prefijo si deseas instalar multiples blogs en una sola base de datos.
 * Emplea solo números, letras y guión bajo.
 */
$table_prefix  = 'wp_';

/**
 * Idioma de WordPress.
 *
 * Cambia lo siguiente para tener WordPress en tu idioma. El correspondiente archivo MO
 * del lenguaje elegido debe encontrarse en wp-content/languages.
 * Por ejemplo, instala ca_ES.mo copiándolo a wp-content/languages y define WPLANG como 'ca_ES'
 * para traducir WordPress al catalán.
 */
define('WPLANG', 'es_ES');

/**
 * Para desarrolladores: modo debug de WordPress.
 *
 * Cambia esto a true para activar la muestra de avisos durante el desarrollo.
 * Se recomienda encarecidamente a los desarrolladores de temas y plugins que usen WP_DEBUG
 * en sus entornos de desarrollo.
 */
define('WP_DEBUG', false);

/* ¡Eso es todo, deja de editar! Feliz blogging */

/** WordPress absolute path to the Wordpress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

