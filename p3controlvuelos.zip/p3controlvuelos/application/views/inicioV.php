<!--
CLAUDIO SERRANO
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>css/estilo.css" >
        <script src="<?php echo base_url(); ?>js/jquery_1.4.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>js/jquery_validate.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>js/script.js" type="text/javascript"></script>  

        <title>CONTROL DE VUELOS - ELECTIVO VI</title>
    </head>
    <body>
      
        <h1>Control de Vuelos</h1>
        <h2>Claudio Serrano - Hervoy Ancacura</h2>
        <h2>Profesor : Alejandro Sanhueza</h2>
        <h2>Profesor lab: Manuel Torres</h2>
          <img src="<?php echo base_url() ?>images/logo.png">
        <h3>Viaje con nosotros</h3>
        
        <div>
            <a href="<?php echo base_url() ?>login">Toma de Vuelos</a>
        </div>


    </body>
</html>
