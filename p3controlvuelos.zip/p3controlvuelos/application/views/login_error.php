<!DOCTYPE html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>css/estilo.css" >
    <script src="<?php echo base_url(); ?>js/jquery_1.4.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>js/jquery_validate.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>js/script.js" type="text/javascript"></script>  

</head>

<body>
    Error en el inicio de sesión
    <a href="login">Volver</a>
    <a href="login/registro">Regitrarse</a>
</body>
</html>