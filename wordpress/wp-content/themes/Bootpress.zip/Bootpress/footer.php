<hr>



<footer>

<p>&copy; Online Mastery 2013</p>

</footer>



</div> <!-- /container -->



<?php wp_footer();?>



</body>

</html>

